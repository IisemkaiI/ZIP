import tkinter as tk
from tkinter import messagebox

# Выполняем выбранную арифметическую операцию без eval().
def calculate():
    try:
        first = float(first_entry.get().replace(",", "."))
        second = float(second_entry.get().replace(",", "."))
        operation = operation_box.get()

        if operation == "+":
            answer = first + second
        elif operation == "−":
            answer = first - second
        elif operation == "×":
            answer = first * second
        elif operation == "÷":
            if second == 0:
                raise ZeroDivisionError("На ноль делить нельзя.")
            answer = first / second
        else:
            return

        result.config(text=f"Ответ: {answer:g}")
    except ValueError:
        messagebox.showwarning("Проверь ввод", "Введи числа в оба поля.")
    except ZeroDivisionError as error:
        messagebox.showwarning("Ошибка вычисления", str(error))

root = tk.Tk()
root.title("Калькулятор")
root.geometry("360x280")
root.resizable(False, False)

tk.Label(root, text="Первое число").pack(pady=(16, 4))
first_entry = tk.Entry(root, justify="center")
first_entry.pack()

tk.Label(root, text="Операция").pack(pady=(10, 4))
operation_box = tk.StringVar(value="+")
# OptionMenu создаёт простой выпадающий список операций.
tk.OptionMenu(root, operation_box, "+", "−", "×", "÷").pack()

tk.Label(root, text="Второе число").pack(pady=(10, 4))
second_entry = tk.Entry(root, justify="center")
second_entry.pack()

tk.Button(root, text="Посчитать", command=calculate).pack(pady=12)
result = tk.Label(root, text="Ответ появится здесь", font=("Arial", 12, "bold"))
result.pack()
root.mainloop()
