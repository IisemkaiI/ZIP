"""Главные URL-адреса сайта: главная страница и панель администратора."""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("tasks.urls")),  # Передаём адреса приложения tasks.
]
