#!/usr/bin/env python
"""Команда управления Django: запуск сервера, миграции и админ-команды."""
import os
import sys

if __name__ == "__main__":
    # Django читает настройки из модуля config/settings.py.
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
