"""Модели — описание таблиц базы данных на языке Python."""
from django.db import models


class Task(models.Model):
    # Короткое название задачи, которое вводит пользователь.
    title = models.CharField("Название", max_length=160)
    # Галочка выполнения.
    done = models.BooleanField("Выполнено", default=False)
    # Django сам запишет дату и время создания.
    created_at = models.DateTimeField("Создано", auto_now_add=True)

    class Meta:
        ordering = ["done", "-created_at"]
        verbose_name = "задача"
        verbose_name_plural = "задачи"

    def __str__(self):
        return self.title
