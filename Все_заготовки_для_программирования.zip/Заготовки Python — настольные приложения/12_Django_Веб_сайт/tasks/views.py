"""Представления (views) принимают запрос и выбирают, какой ответ показать."""
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .forms import TaskForm
from .models import Task


def index(request):
    # POST добавляет задачу, GET просто показывает список.
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("tasks:index")  # Обновление страницы не отправит форму повторно.
    else:
        form = TaskForm()
    return render(request, "tasks/index.html", {"form": form, "tasks": Task.objects.all()})


def home(request):
    """Каталог учебных сайтов: от главной страницы можно перейти к каждому примеру."""
    examples = [
        {"url": "tasks:portfolio", "number": "01", "title": "Портфолио", "kind": "Дизайн и услуги", "text": "Страница специалиста с проектами, описанием и контактами."},
        {"url": "tasks:blog", "number": "02", "title": "Блог", "kind": "Статьи и новости", "text": "Лента публикаций с категориями, датами и кратким текстом."},
        {"url": "tasks:shop", "number": "03", "title": "Магазин", "kind": "Каталог товаров", "text": "Карточки товаров, цены, описания и кнопки действий."},
        {"url": "tasks:cafe", "number": "04", "title": "Кафе", "kind": "Меню и контакты", "text": "Меню по категориям, часы работы и адрес заведения."},
        {"url": "tasks:courses", "number": "05", "title": "Онлайн-курсы", "kind": "Обучение", "text": "Каталог программ с уровнем, длительностью и уроками."},
        {"url": "tasks:index", "number": "06", "title": "Список дел", "kind": "Работа с базой", "text": "Рабочий пример: задачи сохраняются в SQLite и меняют статус."},
    ]
    return render(request, "tasks/home.html", {"examples": examples})


def portfolio(request):
    projects = [
        {"tag": "БРЕНДИНГ", "title": "Тёплый хлеб", "text": "Фирменный стиль небольшой городской пекарни."},
        {"tag": "ВЕБ-ДИЗАЙН", "title": "Лесной дом", "text": "Сайт для аренды уютных домиков за городом."},
        {"tag": "ИЛЛЮСТРАЦИЯ", "title": "Птицы рядом", "text": "Набор иллюстраций для образовательного проекта."},
    ]
    return render(request, "tasks/portfolio.html", {"projects": projects})


def blog(request):
    posts = [
        {"category": "Разработка", "date": "12 октября", "title": "Как устроена веб-страница", "text": "Браузер отправляет запрос, Django находит нужный адрес, выполняет представление и возвращает HTML-шаблон."},
        {"category": "Учёба", "date": "8 октября", "title": "Зачем сайту база данных", "text": "Модель описывает данные, а ORM помогает читать и сохранять их через Python-код."},
        {"category": "Практика", "date": "2 октября", "title": "Что такое URL-маршрут", "text": "Маршрут связывает адрес сайта с функцией, которая должна обработать запрос."},
    ]
    return render(request, "tasks/blog.html", {"posts": posts})


def shop(request):
    products = [
        {"emoji": "🎧", "category": "Аксессуары", "title": "Наушники Wave", "text": "Лёгкие беспроводные наушники на каждый день.", "price": "4 990 ₽", "color": "lavender"},
        {"emoji": "⌚", "category": "Гаджеты", "title": "Часы Tempo", "text": "Минималистичные часы с ярким экраном.", "price": "7 490 ₽", "color": "peach"},
        {"emoji": "🔊", "category": "Аудио", "title": "Колонка Mini", "text": "Компактная колонка для комнаты и прогулок.", "price": "3 290 ₽", "color": "mint"},
    ]
    return render(request, "tasks/shop.html", {"products": products})


def cafe(request):
    menu = [
        {"section": "Завтраки", "items": [{"name": "Сырники со сметаной", "detail": "Творог, ягоды, мёд", "price": "390 ₽"}, {"name": "Тост с авокадо", "detail": "Яйцо пашот, зелень", "price": "460 ₽"}]},
        {"section": "Напитки", "items": [{"name": "Капучино", "detail": "Эспрессо и молоко", "price": "220 ₽"}, {"name": "Чай с облепихой", "detail": "Имбирь, мёд, апельсин", "price": "280 ₽"}]},
    ]
    return render(request, "tasks/cafe.html", {"menu": menu})


def courses(request):
    courses_list = [
        {"level": "С НУЛЯ", "title": "Python: первые шаги", "text": "Переменные, условия, циклы и небольшие программы.", "lessons": "12 уроков", "duration": "3 недели"},
        {"level": "ПРАКТИКА", "title": "Создаём сайты на Django", "text": "Маршруты, шаблоны, формы, модели и админка.", "lessons": "18 уроков", "duration": "5 недель"},
        {"level": "ИНТЕРФЕЙСЫ", "title": "HTML и CSS", "text": "Структура страницы, сетки, цвета и адаптивность.", "lessons": "14 уроков", "duration": "4 недели"},
    ]
    return render(request, "tasks/courses.html", {"courses": courses_list})


@require_POST  # Менять задачу разрешаем только отправкой формы, а не обычной ссылкой.
def toggle_task(request, task_id):
    task = get_object_or_404(Task, pk=task_id)
    task.done = not task.done
    task.save(update_fields=["done"])
    return redirect("tasks:index")
