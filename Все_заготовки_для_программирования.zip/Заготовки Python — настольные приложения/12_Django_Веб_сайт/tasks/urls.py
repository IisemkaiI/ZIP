"""URL-маршруты приложения tasks."""
from django.urls import path
from . import views

app_name = "tasks"
urlpatterns = [
    path("", views.home, name="home"),
    path("tasks/", views.index, name="index"),
    path("tasks/<int:task_id>/toggle/", views.toggle_task, name="toggle"),
    path("portfolio/", views.portfolio, name="portfolio"),
    path("blog/", views.blog, name="blog"),
    path("shop/", views.shop, name="shop"),
    path("cafe/", views.cafe, name="cafe"),
    path("courses/", views.courses, name="courses"),
]
