"""Формы превращают введённые пользователем данные в проверенные Python-объекты."""
from django import forms
from .models import Task


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ["title"]  # Чекбокс выполнения меняется отдельной кнопкой.
        widgets = {"title": forms.TextInput(attrs={
            "placeholder": "Например, изучить Django",
            "class": "task-input",
            "maxlength": 160,
        })}
