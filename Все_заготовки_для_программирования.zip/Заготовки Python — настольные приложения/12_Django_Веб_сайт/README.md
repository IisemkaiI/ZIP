# Django: несколько учебных сайтов

В одном Django-проекте собраны несколько простых сайтов разных специализаций. Запусти сервер один раз и переходи по ссылкам с главной страницы. Комментарии в Python-коде объясняют, как связаны URL-адреса, представления, формы, модели и шаблоны.

## Примеры

- Главная страница-каталог — `/`.
- Портфолио дизайнера — `/portfolio/`.
- Блог о веб-разработке — `/blog/`.
- Каталог интернет-магазина — `/shop/` (кнопки покупки демонстрационные).
- Кафе с меню, адресом и временем работы — `/cafe/`.
- Каталог онлайн-курсов — `/courses/` (кнопки демонстрационные).
- Рабочий список дел на SQLite — `/tasks/`.
- Админ-панель Django — `/admin/`.

## Запуск в Windows PowerShell

Нужен Python 3.10 или новее. В Django 5.2 есть поддержка Python 3.10+; эта версия Django относится к ветке LTS. [Официальная документация](https://docs.djangoproject.com/en/5.2/releases/5.2/).

Открой PowerShell в этой папке и выполняй команды по очереди:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py manage.py makemigrations tasks
py manage.py migrate
py manage.py runserver
```

Открой `http://127.0.0.1:8000/`. Чтобы остановить сервер, нажми `Ctrl+C`.

Если PowerShell заблокировал активацию окружения, используй Python внутри него напрямую: `\.venv\Scripts\python.exe manage.py runserver` (перед этим так же выполни pip install и migrate).

## Панель администратора

Создай администратора командой `py manage.py createsuperuser`, затем открой `http://127.0.0.1:8000/admin/`.

## Где искать код

- `config/settings.py` — настройки сайта, приложений и базы данных.
- `config/urls.py`, `tasks/urls.py` — адреса страниц.
- `tasks/views.py` — данные и логика каждого примера.
- `tasks/models.py`, `tasks/forms.py` — база данных и форма списка дел.
- `templates/tasks/` — отдельные HTML-шаблоны страниц.
- `static/css/style.css` — стили и адаптация под узкий экран.

`DEBUG=True` и учебный `SECRET_KEY` подходят только для разработки на своём компьютере. Не публикуй этот пример в интернете без настройки production-параметров.
