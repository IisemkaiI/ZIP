import tkinter as tk
from tkinter import ttk

# BooleanVar хранит состояние флажка, StringVar — выбранный текст.
notifications = tk.BooleanVar(value=True)
color_choice = tk.StringVar(value="Синий")

def save_settings():
    # get() читает текущее значение переменной Tkinter.
    notice = "включены" if notifications.get() else "выключены"
    result.config(text=f"Уведомления {notice}; цвет: {color_choice.get()}")

root = tk.Tk()
root.title("Настройки приложения")
root.geometry("400x320")

settings = ttk.LabelFrame(root, text="Параметры", padding=16)
settings.pack(fill="both", expand=True, padx=20, pady=20)

# Checkbutton — флажок: настройка может быть включена или выключена.
ttk.Checkbutton(settings, text="Показывать уведомления", variable=notifications).pack(anchor="w", pady=8)

# Radiobutton — выбор только одного варианта из группы.
ttk.Label(settings, text="Цвет оформления:").pack(anchor="w", pady=(12, 4))
for color in ("Синий", "Зелёный", "Красный"):
    ttk.Radiobutton(settings, text=color, value=color, variable=color_choice).pack(anchor="w")

ttk.Button(settings, text="Применить", command=save_settings).pack(anchor="w", pady=14)
result = ttk.Label(settings, text="")
result.pack(anchor="w")
root.mainloop()
