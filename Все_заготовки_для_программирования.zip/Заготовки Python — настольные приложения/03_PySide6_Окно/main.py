import sys
from PySide6.QtWidgets import QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Моё приложение на PySide6")
        self.resize(420, 260)

        self.label = QLabel("Нажми кнопку, чтобы изменить текст")
        self.label.setStyleSheet("font-size: 16px;")
        button = QPushButton("Нажми меня")
        button.clicked.connect(self.on_button_click)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(button)
        layout.addStretch()

        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

    def on_button_click(self):
        self.label.setText("Кнопка работает!")


app = QApplication(sys.argv)
window = MainWindow()
window.show()
sys.exit(app.exec())
