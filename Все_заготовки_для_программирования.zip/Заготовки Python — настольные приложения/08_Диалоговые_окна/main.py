import tkinter as tk
from tkinter import messagebox, simpledialog

# Открывает стандартное окно подтверждения.
def ask_question():
    answer = messagebox.askyesno("Вопрос", "Тебе нравится Python?")
    if answer:
        status.config(text="Ты ответил: да")
    else:
        status.config(text="Ты ответил: нет")

# Открывает маленькое окно для ввода текста.
def ask_name():
    name = simpledialog.askstring("Имя", "Как тебя зовут?")
    if name:
        status.config(text=f"Привет, {name}!")

root = tk.Tk()
root.title("Диалоговые окна")
root.geometry("400x250")

tk.Label(root, text="Примеры стандартных диалогов", font=("Arial", 14, "bold")).pack(pady=20)
tk.Button(root, text="Задать вопрос", command=ask_question).pack(pady=6)
tk.Button(root, text="Спросить имя", command=ask_name).pack(pady=6)
status = tk.Label(root, text="Результат появится здесь")
status.pack(pady=16)
root.mainloop()
