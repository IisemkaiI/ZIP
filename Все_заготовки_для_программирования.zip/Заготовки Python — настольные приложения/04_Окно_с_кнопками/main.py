import tkinter as tk
from tkinter import messagebox

# Функции ниже выполняются при нажатии на соответствующие кнопки.
def say_hello():
    messagebox.showinfo("Сообщение", "Привет! Эта кнопка открыла окно сообщения.")

def change_color():
    # У Frame можно менять цвет фона через настройку bg.
    content.config(bg="#dff0d8")
    hint.config(bg="#dff0d8", text="Цвет области изменён!")

def reset_color():
    content.config(bg="white")
    hint.config(bg="white", text="Нажми любую кнопку ниже")

# Создаём главное окно и задаём заголовок и размер.
root = tk.Tk()
root.title("Окно с кнопками")
root.geometry("440x280")

# Frame — контейнер, в который удобно помещать другие элементы.
content = tk.Frame(root, bg="white", padx=20, pady=20)
content.pack(fill="both", expand=True)

tk.Label(content, text="Пример: несколько кнопок", font=("Arial", 15, "bold"), bg="white").pack(pady=12)
hint = tk.Label(content, text="Нажми любую кнопку ниже", bg="white")
hint.pack(pady=8)

# command связывает кнопку с функцией. Здесь не ставим скобки после имени функции.
button_row = tk.Frame(content, bg="white")
button_row.pack(pady=12)
tk.Button(button_row, text="Привет", command=say_hello).pack(side="left", padx=5)
tk.Button(button_row, text="Сменить цвет", command=change_color).pack(side="left", padx=5)
tk.Button(button_row, text="Сбросить", command=reset_color).pack(side="left", padx=5)

# Запускаем цикл обработки кликов и событий окна.
root.mainloop()
