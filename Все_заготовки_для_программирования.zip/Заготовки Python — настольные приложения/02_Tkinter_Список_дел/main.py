import sqlite3
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

DB_PATH = Path(__file__).with_name("tasks.db")


def connect_db():
    connection = sqlite3.connect(DB_PATH)
    connection.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, title TEXT NOT NULL)")
    return connection


def refresh_tasks():
    task_list.delete(0, tk.END)
    with connect_db() as connection:
        rows = connection.execute("SELECT id, title FROM tasks ORDER BY id DESC").fetchall()
    for task_id, title in rows:
        task_list.insert(tk.END, f"{task_id}. {title}")


def add_task():
    title = task_entry.get().strip()
    if not title:
        messagebox.showinfo("Список дел", "Напиши дело перед добавлением.")
        return
    with connect_db() as connection:
        connection.execute("INSERT INTO tasks (title) VALUES (?)", (title,))
    task_entry.delete(0, tk.END)
    refresh_tasks()


def delete_task():
    selection = task_list.curselection()
    if not selection:
        messagebox.showinfo("Список дел", "Сначала выбери дело в списке.")
        return
    task_id = int(task_list.get(selection[0]).split(".", 1)[0])
    with connect_db() as connection:
        connection.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    refresh_tasks()


root = tk.Tk()
root.title("Список дел")
root.geometry("420x360")
root.minsize(340, 280)

tk.Label(root, text="Мои дела", font=("Arial", 16, "bold")).pack(pady=12)
input_row = tk.Frame(root)
input_row.pack(fill="x", padx=14)
task_entry = tk.Entry(input_row)
task_entry.pack(side="left", fill="x", expand=True)
tk.Button(input_row, text="Добавить", command=add_task).pack(side="left", padx=(8, 0))

task_list = tk.Listbox(root, height=10)
task_list.pack(fill="both", expand=True, padx=14, pady=12)
tk.Button(root, text="Удалить выбранное", command=delete_task).pack(pady=(0, 12))

refresh_tasks()
root.mainloop()
