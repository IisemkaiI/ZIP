import tkinter as tk
from tkinter import messagebox


def greet():
    name = name_entry.get().strip()
    if not name:
        messagebox.showinfo("Приветствие", "Сначала введи имя.")
        return
    result_label.config(text=f"Привет, {name}!")


root = tk.Tk()
root.title("Моё первое приложение")
root.geometry("360x220")
root.minsize(300, 180)

heading = tk.Label(root, text="Пример приложения на Tkinter", font=("Arial", 14, "bold"))
heading.pack(pady=(22, 12))

tk.Label(root, text="Как тебя зовут?").pack()
name_entry = tk.Entry(root, width=30)
name_entry.pack(pady=8)
name_entry.focus()

tk.Button(root, text="Поздороваться", command=greet).pack(pady=4)
result_label = tk.Label(root, text="")
result_label.pack(pady=8)

root.mainloop()
