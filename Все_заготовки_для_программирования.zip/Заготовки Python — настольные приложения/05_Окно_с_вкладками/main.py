import tkinter as tk
from tkinter import ttk

# Функция меняет подпись на первой вкладке.
def show_message():
    result.config(text="Кнопка на вкладке нажата!")

root = tk.Tk()
root.title("Окно с вкладками")
root.geometry("480x320")

# Notebook создаёт панель вкладок. Каждая вкладка — отдельный Frame.
tabs = ttk.Notebook(root)
tabs.pack(fill="both", expand=True, padx=12, pady=12)

first_tab = ttk.Frame(tabs, padding=20)
second_tab = ttk.Frame(tabs, padding=20)
# Текст здесь становится названием вкладки.
tabs.add(first_tab, text="Главная")
tabs.add(second_tab, text="Настройки")

# Содержимое первой вкладки.
ttk.Label(first_tab, text="Это первая вкладка", font=("Arial", 14)).pack(pady=12)
result = ttk.Label(first_tab, text="")
result.pack(pady=8)
ttk.Button(first_tab, text="Нажми меня", command=show_message).pack()

# Содержимое второй вкладки.
ttk.Label(second_tab, text="Это вторая вкладка").pack(anchor="w", pady=8)
tk_theme = ttk.Label(second_tab, text="Добавь сюда свои настройки или кнопки")
tk_theme.pack(anchor="w")
ttk.Button(second_tab, text="Пример кнопки").pack(anchor="w", pady=12)

# В Tkinter вызов mainloop держит окно открытым и обрабатывает события.
root.mainloop()
