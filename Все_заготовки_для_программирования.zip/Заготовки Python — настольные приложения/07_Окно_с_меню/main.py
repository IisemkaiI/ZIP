import tkinter as tk
from tkinter import messagebox

# Эти функции вызываются пунктами меню.
def open_file():
    messagebox.showinfo("Файл", "Здесь можно добавить открытие файла.")

def show_about():
    messagebox.showinfo("О программе", "Учебная заготовка на Tkinter.")

def exit_app():
    root.destroy()  # Закрывает главное окно.

root = tk.Tk()
root.title("Окно с меню")
root.geometry("460x280")

# Создаём верхнюю строку меню.
menu_bar = tk.Menu(root)

# Создаём меню «Файл» и добавляем команды.
file_menu = tk.Menu(menu_bar, tearoff=0)
file_menu.add_command(label="Открыть", command=open_file)
file_menu.add_separator()  # Горизонтальная линия-разделитель.
file_menu.add_command(label="Выход", command=exit_app)
menu_bar.add_cascade(label="Файл", menu=file_menu)

# Добавляем меню справки.
help_menu = tk.Menu(menu_bar, tearoff=0)
help_menu.add_command(label="О программе", command=show_about)
menu_bar.add_cascade(label="Справка", menu=help_menu)

# Подключаем меню к окну.
root.config(menu=menu_bar)

# Основная область окна.
tk.Label(root, text="Открой меню вверху окна", font=("Arial", 15)).pack(pady=70)
root.mainloop()
