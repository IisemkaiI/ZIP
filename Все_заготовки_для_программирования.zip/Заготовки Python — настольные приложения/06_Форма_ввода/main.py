import tkinter as tk
from tkinter import messagebox, ttk

# Проверяем поля и показываем введённые значения.
def submit_form():
    name = name_entry.get().strip()
    group = group_entry.get().strip()
    course = course_box.get()
    if not name or not group:
        messagebox.showwarning("Проверка", "Заполни имя и группу.")
        return
    messagebox.showinfo("Данные формы", f"Имя: {name}\nГруппа: {group}\nКурс: {course}")

root = tk.Tk()
root.title("Форма ввода")
root.geometry("400x300")

# LabelFrame — рамка с заголовком, чтобы объединить поля формы.
form = ttk.LabelFrame(root, text="Анкета", padding=16)
form.pack(fill="both", expand=True, padx=20, pady=20)

# Поле имени.
ttk.Label(form, text="Имя:").grid(row=0, column=0, sticky="w", pady=7)
name_entry = ttk.Entry(form, width=28)
name_entry.grid(row=0, column=1, sticky="ew", pady=7)

# Поле группы.
ttk.Label(form, text="Группа:").grid(row=1, column=0, sticky="w", pady=7)
group_entry = ttk.Entry(form, width=28)
group_entry.grid(row=1, column=1, sticky="ew", pady=7)

# Выпадающий список: пользователь выбирает один вариант.
ttk.Label(form, text="Курс:").grid(row=2, column=0, sticky="w", pady=7)
course_box = ttk.Combobox(form, values=["Python", "Информатика", "Другое"], state="readonly")
course_box.current(0)
course_box.grid(row=2, column=1, sticky="ew", pady=7)

# Кнопка отправки формы вызывает функцию submit_form.
ttk.Button(form, text="Показать данные", command=submit_form).grid(row=3, column=0, columnspan=2, pady=16)
form.columnconfigure(1, weight=1)
root.mainloop()
