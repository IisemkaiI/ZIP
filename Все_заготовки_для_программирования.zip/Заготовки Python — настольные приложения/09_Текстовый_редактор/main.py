import tkinter as tk
from tkinter import filedialog, messagebox

current_file = None  # Здесь запоминаем путь открытого файла.

def open_file():
    global current_file
    # Диалог выбора файла; если пользователь отменил, выходим из функции.
    path = filedialog.askopenfilename(
        title="Открыть текстовый файл",
        filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
    )
    if not path:
        return
    try:
        # utf-8 позволяет корректно читать русский текст.
        with open(path, "r", encoding="utf-8") as file:
            text_area.delete("1.0", tk.END)  # Удаляем прежний текст.
            text_area.insert("1.0", file.read())
        current_file = path
        status.config(text=f"Открыт файл: {path}")
    except OSError as error:
        messagebox.showerror("Ошибка", f"Не получилось открыть файл:\n{error}")

def save_file():
    global current_file
    # Если файл ещё не выбран, сначала показываем диалог «Сохранить как».
    path = current_file or filedialog.asksaveasfilename(
        title="Сохранить текст",
        defaultextension=".txt",
        filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
    )
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as file:
            file.write(text_area.get("1.0", "end-1c"))
        current_file = path
        status.config(text=f"Сохранено: {path}")
    except OSError as error:
        messagebox.showerror("Ошибка", f"Не получилось сохранить файл:\n{error}")

root = tk.Tk()
root.title("Простой текстовый редактор")
root.geometry("640x440")

# Панель кнопок сверху.
toolbar = tk.Frame(root, padx=8, pady=8)
toolbar.pack(fill="x")
tk.Button(toolbar, text="Открыть", command=open_file).pack(side="left", padx=4)
tk.Button(toolbar, text="Сохранить", command=save_file).pack(side="left", padx=4)

# Text — многострочное поле. Scrollbar добавляет полосу прокрутки.
text_area = tk.Text(root, wrap="word", undo=True)
scrollbar = tk.Scrollbar(root, command=text_area.yview)
text_area.configure(yscrollcommand=scrollbar.set)
scrollbar.pack(side="right", fill="y")
text_area.pack(fill="both", expand=True, padx=(8, 0), pady=(0, 8))

status = tk.Label(root, text="Новый документ", anchor="w", padx=8)
status.pack(fill="x")
root.mainloop()
