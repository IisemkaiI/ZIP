package ru.azizo.mobiletemplates;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/** Минимальный помощник SQLite: создаёт таблицу и сохраняет текст заметок. */
public class NotesDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "notes.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NOTES = "notes";

    public NotesDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Таблица имеет автоинкрементный ID и текст заметки.
        db.execSQL("CREATE TABLE " + TABLE_NOTES + " (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // В учебной заготовке миграций нет. Реальные изменения таблиц оформляют по версиям.
    }

    public void addNote(String text) {
        ContentValues values = new ContentValues();
        values.put("text", text);
        getWritableDatabase().insert(TABLE_NOTES, null, values);
    }

    public Cursor getAllNotes() {
        return getReadableDatabase().query(TABLE_NOTES, new String[]{"id", "text"},
                null, null, null, null, "id DESC");
    }

    public void deleteNote(long id) {
        getWritableDatabase().delete(TABLE_NOTES, "id = ?", new String[]{String.valueOf(id)});
    }
}
