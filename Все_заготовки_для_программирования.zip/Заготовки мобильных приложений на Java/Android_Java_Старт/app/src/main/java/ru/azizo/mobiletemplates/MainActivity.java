package ru.azizo.mobiletemplates;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

/** Главный экран: отсюда открываются примеры мобильных интерфейсов. */
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Каждая кнопка открывает отдельный экран через Intent.
        Button buttonsExample = findViewById(R.id.openButtons);
        Button formExample = findViewById(R.id.openForm);
        Button notesExample = findViewById(R.id.openNotes);

        buttonsExample.setOnClickListener(view -> openScreen(ButtonsActivity.class));
        formExample.setOnClickListener(view -> openScreen(ProfileActivity.class));
        notesExample.setOnClickListener(view -> openScreen(NotesActivity.class));
    }

    private void openScreen(Class<?> screen) {
        startActivity(new Intent(this, screen));
    }
}
