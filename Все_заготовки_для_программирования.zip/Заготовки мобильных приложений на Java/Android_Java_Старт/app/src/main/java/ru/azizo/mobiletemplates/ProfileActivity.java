package ru.azizo.mobiletemplates;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/** Пример формы: читаем текст, проверяем поля и показываем результат. */
public class ProfileActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        EditText nameField = findViewById(R.id.nameField);
        EditText goalField = findViewById(R.id.goalField);
        Button saveButton = findViewById(R.id.saveProfile);

        saveButton.setOnClickListener(view -> {
            String name = nameField.getText().toString().trim();
            String goal = goalField.getText().toString().trim();
            if (name.isEmpty()) {
                nameField.setError("Введи имя");
                return;
            }
            if (goal.isEmpty()) goal = "пока не выбрана";
            Toast.makeText(this, "Привет, " + name + "! Цель: " + goal,
                    Toast.LENGTH_LONG).show();
        });
    }
}
