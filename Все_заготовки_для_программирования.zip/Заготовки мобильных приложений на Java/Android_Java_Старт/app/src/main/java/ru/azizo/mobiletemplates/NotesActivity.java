package ru.azizo.mobiletemplates;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

/** Пример списка, ввода заметки и хранения записей в локальной SQLite-базе. */
public class NotesActivity extends Activity {
    private NotesDatabase database;
    private ArrayAdapter<String> adapter;
    private final ArrayList<Long> noteIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        database = new NotesDatabase(this);
        EditText noteField = findViewById(R.id.noteField);
        Button addButton = findViewById(R.id.addNoteButton);
        ListView notesList = findViewById(R.id.notesList);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        notesList.setAdapter(adapter);
        refreshNotes();

        addButton.setOnClickListener(view -> {
            String text = noteField.getText().toString().trim();
            if (text.isEmpty()) {
                noteField.setError("Напиши текст заметки");
                return;
            }
            database.addNote(text);
            noteField.setText("");
            refreshNotes();
        });

        // Долгое нажатие показывает подтверждение, затем удаляет запись из SQLite.
        notesList.setOnItemLongClickListener((parent, view, position, id) -> {
            new AlertDialog.Builder(this)
                    .setTitle("Удалить заметку?")
                    .setMessage(adapter.getItem(position))
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (dialog, which) -> {
                        database.deleteNote(noteIds.get(position));
                        refreshNotes();
                    }).show();
            return true;
        });
    }

    private void refreshNotes() {
        adapter.clear();
        noteIds.clear();
        try (Cursor cursor = database.getAllNotes()) {
            while (cursor.moveToNext()) {
                noteIds.add(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
                adapter.add(cursor.getString(cursor.getColumnIndexOrThrow("text")));
            }
        }
        if (adapter.isEmpty()) Toast.makeText(this, "Пока заметок нет", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
