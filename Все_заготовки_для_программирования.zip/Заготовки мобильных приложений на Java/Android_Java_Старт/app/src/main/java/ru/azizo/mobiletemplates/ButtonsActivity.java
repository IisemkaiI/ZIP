package ru.azizo.mobiletemplates;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/** Пример обработчиков нажатия, счётчика и короткого сообщения Toast. */
public class ButtonsActivity extends Activity {
    private int count = 0;
    private TextView countLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buttons);
        countLabel = findViewById(R.id.countLabel);
        Button plusButton = findViewById(R.id.plusButton);
        Button resetButton = findViewById(R.id.resetButton);
        Button toastButton = findViewById(R.id.toastButton);

        // Лямбда-функции выполняются при нажатии на соответствующую кнопку.
        plusButton.setOnClickListener(view -> {
            count++;
            countLabel.setText("Нажатий: " + count);
        });
        resetButton.setOnClickListener(view -> {
            count = 0;
            countLabel.setText("Нажатий: 0");
        });
        toastButton.setOnClickListener(view ->
                Toast.makeText(this, "Кнопка работает!", Toast.LENGTH_SHORT).show());
    }
}
