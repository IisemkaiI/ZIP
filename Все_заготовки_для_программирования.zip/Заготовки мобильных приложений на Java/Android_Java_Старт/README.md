# Заготовка Android-приложения на Java

Учебный проект Android Studio: главное меню и три отдельных экрана с комментариями. Макеты сделаны на XML, логика — на Java. Один проект показывает обработчики кнопок, формы, переход между Activity, список и локальную базу SQLite.

## Запуск

1. Установи Android Studio и компоненты Android SDK.
2. В Android Studio выбери **Open** и укажи папку `Android_Java_Старт`.
3. Дождись Gradle Sync. Если появится предложение установить платформу SDK 36 — согласись.
4. Выбери виртуальный телефон в Device Manager или подключи Android-телефон с включённой USB-отладкой.
5. Нажми зелёную кнопку **Run**.

Проект использует Gradle Wrapper. Для сборки требуется JDK 17, Android Gradle Plugin 9.4.0 и Gradle 9.6.0; совместимость версий сверена с официальными таблицами Android. [Официальная таблица Android Gradle Plugin](https://developer.android.com/build/releases/about-agp).

## Экраны

- **Главный экран** — переходы по примерам через `Intent`.
- **Кнопки и счётчик** — `setOnClickListener`, изменение текста и `Toast`.
- **Форма профиля** — `EditText`, чтение строк, проверка пустого поля.
- **Заметки** — `ListView`, `SQLiteOpenHelper`, добавление и удаление записей долгим нажатием.

## Где код

- `app/src/main/java/ru/azizo/mobiletemplates/` — Java-классы экранов и база данных.
- `app/src/main/res/layout/` — XML-разметка экранов.
- `app/src/main/res/values/` — тема приложения и подписи.
- `app/src/main/AndroidManifest.xml` — список экранов и стартовая Activity.
- `app/build.gradle` — настройки сборки Android-приложения.

Пакет приложения `ru.azizo.mobiletemplates` можно заменить в Gradle, Manifest и исходниках, если будете публиковать собственную работу.
