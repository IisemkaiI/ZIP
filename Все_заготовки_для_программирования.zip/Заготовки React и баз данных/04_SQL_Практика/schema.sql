-- Учебная база для онлайн-школы. Запусти весь файл в SQLite.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    price INTEGER NOT NULL CHECK (price >= 0)
);

-- Связующая таблица: один ученик может выбрать несколько курсов,
-- а на одном курсе учится несколько учеников.
CREATE TABLE IF NOT EXISTS enrollments (
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    enrolled_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (student_id, course_id)
);

INSERT OR IGNORE INTO students (id, name, email) VALUES
    (1, 'Аня', 'anya@example.com'),
    (2, 'Илья', 'ilya@example.com'),
    (3, 'Маша', 'masha@example.com');

INSERT OR IGNORE INTO courses (id, title, price) VALUES
    (1, 'Python с нуля', 2500),
    (2, 'Сайты на Django', 3900),
    (3, 'React для начинающих', 4200);

INSERT OR IGNORE INTO enrollments (student_id, course_id) VALUES
    (1, 1), (1, 2), (2, 3), (3, 1);