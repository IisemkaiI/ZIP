-- 1. Показать все курсы дороже 3000.
SELECT title, price FROM courses WHERE price > 3000 ORDER BY price DESC;

-- 2. Найти ученика по части имени.
SELECT id, name, email FROM students WHERE name LIKE '%ан%';

-- 3. JOIN: показать, кто на какие курсы записан.
SELECT students.name AS student, courses.title AS course, enrollments.enrolled_at
FROM enrollments
JOIN students ON students.id = enrollments.student_id
JOIN courses ON courses.id = enrollments.course_id
ORDER BY students.name;

-- 4. GROUP BY: посчитать количество учеников на каждом курсе.
SELECT courses.title, COUNT(enrollments.student_id) AS student_count
FROM courses
LEFT JOIN enrollments ON enrollments.course_id = courses.id
GROUP BY courses.id, courses.title
ORDER BY student_count DESC;

-- 5. UPDATE: изменить цену курса (проверь таблицу запросом SELECT после выполнения).
UPDATE courses SET price = 2800 WHERE id = 1;

-- 6. DELETE: удалить одну запись о зачислении.
DELETE FROM enrollments WHERE student_id = 3 AND course_id = 1;