-- Дополнительные примеры SQLite. Сначала выполни schema.sql.

-- Индекс ускоряет фильтры и сортировку по цене.
CREATE INDEX IF NOT EXISTS idx_courses_price ON courses(price);

-- Представление сохраняет JOIN под понятным именем.
CREATE VIEW IF NOT EXISTS student_course_list AS
SELECT students.name AS student_name, students.email,
       courses.title AS course_title, courses.price, enrollments.enrolled_at
FROM enrollments
JOIN students ON students.id = enrollments.student_id
JOIN courses ON courses.id = enrollments.course_id;

-- Теперь тот же JOIN можно прочитать короче.
SELECT student_name, course_title, price
FROM student_course_list
ORDER BY student_name, course_title;

-- Подзапрос: курсы, цена которых выше средней.
SELECT title, price
FROM courses
WHERE price > (SELECT AVG(price) FROM courses);

-- CTE (WITH): сначала считаем учеников на курсах, потом выбираем популярные.
WITH course_counts AS (
    SELECT course_id, COUNT(*) AS student_count
    FROM enrollments
    GROUP BY course_id
)
SELECT courses.title, COALESCE(course_counts.student_count, 0) AS student_count
FROM courses
LEFT JOIN course_counts ON course_counts.course_id = courses.id
WHERE COALESCE(course_counts.student_count, 0) >= 1;

-- Транзакция: либо обе операции применяются, либо ни одна.
BEGIN TRANSACTION;
UPDATE courses SET price = price + 100 WHERE id = 1;
UPDATE courses SET price = price - 100 WHERE id = 2;
COMMIT;