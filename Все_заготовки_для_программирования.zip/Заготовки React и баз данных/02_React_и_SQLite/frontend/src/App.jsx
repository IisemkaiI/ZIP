import { useEffect, useState } from 'react';

export default function App() {
  const [notes, setNotes] = useState([]);
  const [title, setTitle] = useState('');
  const [editId, setEditId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Загружаем сохранённые заметки при открытии страницы.
  async function loadNotes() {
    setError('');
    try {
      const response = await fetch('/api/notes');
      if (!response.ok) throw new Error('Не удалось получить заметки');
      setNotes(await response.json());
    } catch (err) {
      setError('Не вижу сервер базы. Проверь, запущен ли backend/server.py.');
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { loadNotes(); }, []);

  async function addNote(event) {
    event.preventDefault();
    const cleanTitle = title.trim();
    if (!cleanTitle) return;
    try {
      const response = await fetch(editId ? `/api/notes/${editId}` : '/api/notes', {
        method: editId ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: cleanTitle }),
      });
      if (!response.ok) throw new Error('Не удалось сохранить');
      setTitle('');
      setEditId(null);
      await loadNotes();
    } catch (err) { setError('Не получилось сохранить. Проверь работу backend.'); }
  }

  function startEditing(note) {
    setTitle(note.title);
    setEditId(note.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function deleteNote(id) {
    try {
      const response = await fetch(`/api/notes/${id}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Не удалось удалить');
      setNotes((current) => current.filter((note) => note.id !== id));
    } catch (err) { setError('Не получилось удалить заметку.'); }
  }

  return (
    <main className="app">
      <header className="header"><span className="mark">✳</span><span>LOCAL NOTES</span><span className="stack">REACT + PYTHON + SQLITE</span></header>
      <section className="intro"><p className="kicker">ПОЛНОСТЬЮ РАБОЧИЙ ПРИМЕР</p><h1>Идеи должны<br /><em>оставаться.</em></h1><p>React отправляет запросы, Python API обрабатывает их, SQLite хранит заметки на компьютере.</p></section>
      <form className="add-form" onSubmit={addNote}>
        <input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={160} placeholder="Запиши новую идею…" aria-label="Текст заметки" />
        <button type="submit">{editId ? 'Сохранить' : 'Добавить'} <span>↗</span></button>
      </form>
      {editId && <button className="cancel-edit" type="button" onClick={() => { setEditId(null); setTitle(''); }}>Отменить редактирование</button>}
      {error && <p className="error">{error} <button className="retry" onClick={loadNotes} type="button">Повторить</button></p>}
      <div className="list-heading"><h2>Мои заметки</h2><span>{notes.length} шт.</span></div>
      {loading ? <p className="empty">Загружаю…</p> : notes.length === 0 ? <p className="empty">Пока пусто. Добавь первую заметку выше.</p> :
        <ul className="notes">{notes.map((note) => <li key={note.id}><span className="bullet">✳</span><span className="note-title">{note.title}</span><time>{note.created_at}</time><button type="button" onClick={() => startEditing(note)} aria-label="Редактировать заметку">✎</button><button type="button" onClick={() => deleteNote(note.id)} aria-label="Удалить заметку">×</button></li>)}</ul>}
      <footer>Данные лежат в файле <code>backend/notes.db</code></footer>
    </main>
  );
}
