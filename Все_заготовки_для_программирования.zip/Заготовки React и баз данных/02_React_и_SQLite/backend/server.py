"""Учебный JSON API: React обращается к нему, а Python читает и пишет SQLite."""
from datetime import datetime
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sqlite3
from urllib.parse import urlparse

DB_PATH = Path(__file__).with_name("notes.db")
HOST = "127.0.0.1"  # Только этот компьютер, чтобы учебный сервер не торчал в сеть.
PORT = 8000


def connect_db():
    """Открывает соединение; row_factory позволяет читать поля по имени."""
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


@contextmanager
def database():
    """Закрывает соединение даже в случае ошибки и сохраняет успешные изменения."""
    connection = connect_db()
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def initialize_database():
    """Создаёт таблицу один раз перед стартом HTTP-сервера."""
    with database() as connection:
        connection.execute("""
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)


class NotesApiHandler(BaseHTTPRequestHandler):
    """Обработчики GET, POST и DELETE для небольшого REST-подобного API."""

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if urlparse(self.path).path != "/api/notes":
            self.send_json({"error": "Not found"}, 404)
            return
        with database() as db:
            rows = db.execute("SELECT id, title, created_at FROM notes ORDER BY id DESC").fetchall()
        self.send_json([dict(row) for row in rows])

    def do_POST(self):
        if urlparse(self.path).path != "/api/notes":
            self.send_json({"error": "Not found"}, 404)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 10_000:
                self.send_json({"error": "Invalid request size"}, 400)
                return
            payload = json.loads(self.rfile.read(size).decode("utf-8"))
            if not isinstance(payload, dict):
                self.send_json({"error": "Expected a JSON object with a title"}, 400)
                return
            title = str(payload.get("title", "")).strip()
            if not title or len(title) > 160:
                self.send_json({"error": "Title must contain 1 to 160 characters"}, 400)
                return
            created_at = datetime.now().astimezone().strftime("%d.%m.%Y %H:%M")
            with database() as db:
                cursor = db.execute(
                    "INSERT INTO notes (title, created_at) VALUES (?, ?)",
                    (title, created_at),  # Параметры защищают запрос от SQL-инъекций.
                )
                note_id = cursor.lastrowid
            self.send_json({"id": note_id, "title": title, "created_at": created_at}, 201)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            self.send_json({"error": "Expected a JSON object with a title"}, 400)

    def do_DELETE(self):
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[:2] != ["api", "notes"] or not parts[2].isdigit():
            self.send_json({"error": "Not found"}, 404)
            return
        with database() as db:
            cursor = db.execute("DELETE FROM notes WHERE id = ?", (int(parts[2]),))
        if cursor.rowcount == 0:
            self.send_json({"error": "Note not found"}, 404)
        else:
            self.send_json({"deleted": True})

    def do_PUT(self):
        """Обновить текст заметки: PUT /api/notes/<id>."""
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) != 3 or parts[:2] != ["api", "notes"] or not parts[2].isdigit():
            self.send_json({"error": "Not found"}, 404)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 10_000:
                self.send_json({"error": "Invalid request size"}, 400)
                return
            payload = json.loads(self.rfile.read(size).decode("utf-8"))
            if not isinstance(payload, dict):
                self.send_json({"error": "Expected a JSON object with a title"}, 400)
                return
            title = str(payload.get("title", "")).strip()
            if not title or len(title) > 160:
                self.send_json({"error": "Title must contain 1 to 160 characters"}, 400)
                return
            with database() as db:
                cursor = db.execute("UPDATE notes SET title = ? WHERE id = ?", (title, int(parts[2])))
            if cursor.rowcount == 0:
                self.send_json({"error": "Note not found"}, 404)
            else:
                self.send_json({"id": int(parts[2]), "title": title, "updated": True})
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            self.send_json({"error": "Expected a JSON object with a title"}, 400)

    def log_message(self, fmt, *args):
        # Оставляем короткий лог в терминале, чтобы было видно запросы браузера.
        print(f"[API] {self.address_string()} - {fmt % args}")


if __name__ == "__main__":
    initialize_database()  # Подготовить таблицу до запуска сервера.
    print(f"SQLite API запущен: http://{HOST}:{PORT}/api/notes")
    print("Остановка: Ctrl+C")
    try:
        ThreadingHTTPServer((HOST, PORT), NotesApiHandler).serve_forever()
    except KeyboardInterrupt:
        print("\nСервер остановлен.")
