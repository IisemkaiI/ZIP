"""Консольный справочник контактов: готовый пример CRUD для SQLite."""
from pathlib import Path
import csv
import sqlite3

DB_PATH = Path(__file__).with_name("contacts.db")


def create_database(connection):
    """Создаём таблицу один раз. IF NOT EXISTS не удаляет уже записанные данные."""
    connection.execute("""
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT DEFAULT ''
        )
    """)
    connection.commit()


def show_contacts(connection):
    """READ: получить строки и вывести их человеку."""
    rows = connection.execute(
        "SELECT id, name, phone, email FROM contacts ORDER BY name COLLATE NOCASE"
    ).fetchall()
    if not rows:
        print("Контактов пока нет.")
        return
    for row in rows:
        print(f"#{row['id']}  {row['name']} | {row['phone']} | {row['email'] or 'email не указан'}")


def add_contact(connection):
    """CREATE: добавить запись. ? — параметр, он защищает SQL от вставки кода."""
    name = input("Имя: ").strip()
    phone = input("Телефон: ").strip()
    email = input("Email (можно пропустить): ").strip()
    if not name or not phone:
        print("Имя и телефон обязательны.")
        return
    connection.execute(
        "INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)",
        (name, phone, email),
    )
    connection.commit()
    print("Контакт сохранён.")


def find_contacts(connection):
    """SEARCH: LIKE ищет подстроку в имени или телефоне."""
    query = input("Имя или часть телефона: ").strip()
    pattern = f"%{query}%"
    rows = connection.execute(
        "SELECT id, name, phone, email FROM contacts WHERE name LIKE ? OR phone LIKE ?",
        (pattern, pattern),
    ).fetchall()
    for row in rows:
        print(f"#{row['id']}  {row['name']} | {row['phone']} | {row['email']}")
    if not rows:
        print("Совпадений нет.")


def delete_contact(connection):
    """DELETE: удалить одну строку по её ID."""
    raw_id = input("ID контакта: ").strip()
    if not raw_id.isdigit():
        print("ID должен быть числом.")
        return
    cursor = connection.execute("DELETE FROM contacts WHERE id = ?", (int(raw_id),))
    connection.commit()
    print("Удалено." if cursor.rowcount else "Контакт не найден.")


def edit_contact(connection):
    """UPDATE: меняет контакт по ID; пустой ввод оставляет прежнее значение."""
    raw_id = input("ID контакта: ").strip()
    if not raw_id.isdigit():
        print("ID должен быть числом.")
        return
    row = connection.execute(
        "SELECT name, phone, email FROM contacts WHERE id = ?", (int(raw_id),)
    ).fetchone()
    if row is None:
        print("Контакт не найден.")
        return
    name = input(f"Имя [{row['name']}]: ").strip() or row["name"]
    phone = input(f"Телефон [{row['phone']}]: ").strip() or row["phone"]
    email = input(f"Email [{row['email']}]: ").strip() or row["email"]
    connection.execute(
        "UPDATE contacts SET name = ?, phone = ?, email = ? WHERE id = ?",
        (name, phone, email, int(raw_id)),
    )
    connection.commit()
    print("Контакт обновлён.")


def export_csv(connection):
    """Экспортирует данные в CSV, который можно открыть в Excel."""
    export_path = Path(__file__).with_name("contacts_export.csv")
    rows = connection.execute(
        "SELECT id, name, phone, email FROM contacts ORDER BY name COLLATE NOCASE"
    ).fetchall()
    # utf-8-sig помогает Excel на Windows правильно распознавать русский текст.
    with export_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file, delimiter=";")
        writer.writerow(["ID", "Имя", "Телефон", "Email"])
        writer.writerows([row["id"], row["name"], row["phone"], row["email"]] for row in rows)
    print(f"Экспортировано {len(rows)} контактов: {export_path}")


def main():
    with sqlite3.connect(DB_PATH) as connection:
        connection.row_factory = sqlite3.Row
        create_database(connection)
        actions = {"1": show_contacts, "2": add_contact, "3": find_contacts,
                   "4": delete_contact, "5": edit_contact, "6": export_csv}
        while True:
            print("\n=== Справочник контактов ===")
            print("1 — показать  2 — добавить  3 — найти  4 — удалить  5 — изменить  6 — CSV  0 — выход")
            choice = input("Выбор: ").strip()
            if choice == "0":
                break
            action = actions.get(choice)
            if action:
                action(connection)
            else:
                print("Выбери пункт от 0 до 6.")


if __name__ == "__main__":
    main()
