import { useState } from 'react';

const projects = [
  { number: '01', category: 'БРЕНДИНГ', title: 'Тёплый хлеб', color: 'sand', emoji: '🥐' },
  { number: '02', category: 'ВЕБ-ДИЗАЙН', title: 'Лесной дом', color: 'sage', emoji: '🌲' },
  { number: '03', category: 'ИЛЛЮСТРАЦИЯ', title: 'Птицы рядом', color: 'lilac', emoji: '🕊️' },
];
const products = [
  { id: 1, emoji: '🎧', title: 'Наушники Wave', description: 'Лёгкие беспроводные наушники.', price: 4990 },
  { id: 2, emoji: '⌚', title: 'Часы Tempo', description: 'Минималистичные часы на каждый день.', price: 7490 },
  { id: 3, emoji: '🔊', title: 'Колонка Mini', description: 'Компактный звук для комнаты и прогулок.', price: 3290 },
];
const courses = [
  { id: 1, level: 'С НУЛЯ', title: 'Python: первые шаги', lessons: 12, length: '3 недели' },
  { id: 2, level: 'ПРАКТИКА', title: 'Создаём сайты на Django', lessons: 18, length: '5 недель' },
  { id: 3, level: 'ИНТЕРФЕЙСЫ', title: 'React для начинающих', lessons: 16, length: '4 недели' },
];
const posts = [
  { category: 'ДИЗАЙН', date: '12 октября', title: 'Как найти свой стиль', text: 'Наблюдай за тем, что тебя цепляет, собирай референсы и пробуй разные сочетания. Стиль появляется из практики.' },
  { category: 'РАЗРАБОТКА', date: '8 октября', title: 'Зачем сайту React', text: 'React помогает собирать интерфейс из небольших компонентов и обновлять нужную часть страницы после действий пользователя.' },
  { category: 'ЗАМЕТКИ', date: '2 октября', title: 'Маленькие проекты — тоже опыт', text: 'Один законченный учебный проект часто объясняет больше, чем длинный список просмотренных уроков.' },
];

const navItems = [
  { id: 'portfolio', label: 'Портфолио', icon: '✳' },
  { id: 'shop', label: 'Магазин', icon: '▦' },
  { id: 'courses', label: 'Курсы', icon: '▤' },
  { id: 'blog', label: 'Блог', icon: '☰' },
];

export default function App() {
  const [page, setPage] = useState('portfolio');
  const [cart, setCart] = useState(0);
  const [enrolled, setEnrolled] = useState([]);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="logo" href="#home" onClick={() => setPage('portfolio')}><span>◈</span> студия<span className="logo-dot">.</span></a>
        <p className="nav-caption">ПРИМЕРЫ САЙТОВ</p>
        <nav aria-label="Разделы сайта">
          {navItems.map((item) => (
            <button key={item.id} className={`nav-link ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
              <span>{item.icon}</span>{item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom"><span className="live-dot" /> Учебный React-проект</div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <span>Главная <b>/</b> {navItems.find((item) => item.id === page)?.label}</span>
          <span className="topbar-badge">REACT STARTER</span>
        </header>
        {page === 'portfolio' && <PortfolioPage />}
        {page === 'shop' && <ShopPage cart={cart} onAdd={() => setCart((value) => value + 1)} />}
        {page === 'courses' && <CoursesPage enrolled={enrolled} onEnroll={(id) => setEnrolled((old) => [...old, id])} />}
        {page === 'blog' && <BlogPage />}
        <footer className="footer">Меняй текст, цвета и компоненты — это твоя заготовка.</footer>
      </main>
    </div>
  );
}

function BlogPage() {
  return (
    <section className="page-wrap">
      <div className="blog-banner"><p className="eyebrow">ЗАМЕТКИ О ТВОРЧЕСТВЕ И КОДЕ</p><h1>Пишем, чтобы<br />разобраться<span>.</span></h1><p className="lead">Пример новостной ленты: категории, даты и карточки статей.</p></div>
      <div className="section-title"><div><p className="eyebrow">СВЕЖИЕ ПУБЛИКАЦИИ</p><h2>Последние статьи</h2></div><span>{posts.length} записи</span></div>
      <div className="blog-list">{posts.map((post, index) => <article className="blog-card" key={post.title}>
        <div className="blog-meta"><span>{post.category}</span><time>{post.date}</time></div><h3>{post.title}</h3><p>{post.text}</p><a href={`#article-${index + 1}`}>Читать статью <span>→</span></a>
      </article>)}</div>
    </section>
  );
}

function PortfolioPage() {
  return (
    <section className="page-wrap">
      <div className="hero portfolio-hero">
        <div><p className="eyebrow">ДИЗАЙНЕР · МОСКВА</p><h1>Делаю бренды<br />заметными<span>.</span></h1>
          <p className="lead">Привет, я Аня. Создаю визуальные истории, айдентику и сайты для небольших проектов.</p>
          <a className="primary-link" href="mailto:hello@example.com">Обсудить проект <span>↗</span></a></div>
        <div className="portrait"><span>АВ</span><i>✳</i></div>
      </div>
      <div className="section-title"><div><p className="eyebrow">ИЗБРАННЫЕ РАБОТЫ</p><h2>Проекты</h2></div><span>2024 — 2026</span></div>
      <div className="project-grid">{projects.map((project) => <article className="project-card" key={project.number}>
        <div className={`project-art ${project.color}`}><span>{project.category}</span><b>{project.emoji}</b><strong>{project.title}</strong></div>
        <div className="project-caption"><span>{project.title}</span><span>{project.number} ↗</span></div>
      </article>)}</div>
    </section>
  );
}

function ShopPage({ cart, onAdd }) {
  return (
    <section className="page-wrap">
      <div className="shop-heading"><div><p className="eyebrow">ХОРОШИЕ ВЕЩИ НА КАЖДЫЙ ДЕНЬ</p><h1>Wave Store<span>.</span></h1><p className="lead">Карточки каталога, цены и простая интерактивная корзина.</p></div>
        <div className="cart-badge">♧ Корзина <strong>{cart}</strong></div></div>
      <div className="section-title"><div><p className="eyebrow">ВЫБРАЛИ ДЛЯ ТЕБЯ</p><h2>Популярное</h2></div><span>{products.length} товара</span></div>
      <div className="product-grid">{products.map((product) => <article className="product-card" key={product.id}>
        <div className={`product-picture shade-${product.id}`}>{product.emoji}</div><p className="eyebrow">ЭЛЕКТРОНИКА</p><h3>{product.title}</h3><p className="muted">{product.description}</p>
        <div className="product-bottom"><strong>{product.price.toLocaleString('ru-RU')} ₽</strong><button className="round-button" onClick={onAdd} aria-label={`Добавить ${product.title} в корзину`}>+</button></div>
      </article>)}</div>
    </section>
  );
}

function CoursesPage({ enrolled, onEnroll }) {
  return (
    <section className="page-wrap">
      <div className="courses-banner"><p className="eyebrow">УЧИСЬ В СВОЁМ ТЕМПЕ</p><h1>Новые навыки<br />начинаются здесь<span>.</span></h1><p className="lead">Пример образовательного сайта с каталогом занятий и записью на курс.</p></div>
      <div className="section-title"><div><p className="eyebrow">ОНЛАЙН-ПРОГРАММЫ</p><h2>Выбери курс</h2></div><span>3 направления</span></div>
      <div className="course-list">{courses.map((course) => <article className="course-card" key={course.id}>
        <div className="course-number">0{course.id}</div><div className="course-info"><p className="eyebrow">{course.level}</p><h3>{course.title}</h3><span>{course.lessons} уроков · {course.length}</span></div>
        <button className={enrolled.includes(course.id) ? 'enrolled-button' : 'outline-button'} disabled={enrolled.includes(course.id)} onClick={() => onEnroll(course.id)}>
          {enrolled.includes(course.id) ? 'Вы записаны ✓' : 'Записаться ↗'}
        </button>
      </article>)}</div>
    </section>
  );
}
