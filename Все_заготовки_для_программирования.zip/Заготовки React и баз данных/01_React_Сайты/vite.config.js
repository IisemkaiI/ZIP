import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Плагин включает поддержку JSX и быстрое обновление страницы при изменении кода.
export default defineConfig({ plugins: [react()] });